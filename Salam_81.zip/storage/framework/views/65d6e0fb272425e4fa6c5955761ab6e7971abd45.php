<form action="" class="form-inline float-right" method="post" id="top_filter_form">
    <?php echo csrf_field(); ?>
    <label for="top_company_filter"><?php echo e(__('page.company')); ?> : </label>
    <select name="top_company" id="top_company_filter" class="form-control form-control-sm ml-2">
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($top_company == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form><?php /**PATH /home/u888404772/public_html/resources/views/dashboard/top_filter.blade.php ENDPATH**/ ?>