<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.reports')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.purchases_report')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-credit-card"></i>  <?php echo e(__('page.purchases_report')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('purchase.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th><?php echo e(__('page.date')); ?></th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.company')); ?></th>
                                <th><?php echo e(__('page.store')); ?></th>
                                <th><?php echo e(__('page.supplier')); ?></th>
                                <th><?php echo e(__('page.product_qty')); ?></th>
                                <th><?php echo e(__('page.grand_total')); ?></th>
                                <th><?php echo e(__('page.paid')); ?></th>
                                <th><?php echo e(__('page.balance')); ?></th>
                                <th><?php echo e(__('page.purchase_status')); ?></th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total_grand = $total_paid = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $grand_total = $item->orders()->sum('subtotal');
                                    $paid = $item->payments()->sum('amount');
                                    $orders = $item->orders;
                                    $product_array = array();
                                    foreach ($orders as $order) {
                                        $product_name = isset($order->product->name) ? $order->product->name : "product";
                                        $product_quantity = $order->quantity;
                                        array_push($product_array, $product_name."(".$product_quantity.")");
                                    }

                                    $total_grand += $grand_total;
                                    $total_paid += $paid;
                                ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="timestamp"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no"><?php echo e($item->reference_no); ?></td>
                                    <td class="company"><?php echo e($item->company->name); ?></td>
                                    <td class="store"><?php echo e($item->store->name); ?></td>
                                    <td class="supplier" data-id="<?php echo e($item->supplier_id); ?>"><?php echo e($item->supplier->name); ?></td>
                                    <td class="product"><?php echo e(implode(", ", $product_array)); ?></td>
                                    <td class="grand_total"> <?php echo e(number_format($grand_total)); ?> </td>
                                    <td class="paid"> <?php echo e(number_format($paid)); ?> </td>
                                    <td> <?php echo e(number_format($grand_total - $paid)); ?> </td>
                                    <td class="status">
                                        <?php if($item->status == 1): ?>
                                            <span class="badge badge-success"><i class="fa fa-check"></i> <?php echo e(__('page.received')); ?></span>
                                        <?php elseif($item->status == 0): ?>
                                            <span class="badge badge-danger"><i class="fa fa- exclamation-triangle"></i><?php echo e(__('page.pending')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="7"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($total_grand)); ?></td>
                                <td><?php echo e(number_format($total_paid)); ?></td>
                                <td><?php echo e(number_format($total_grand - $total_paid)); ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script>
    $(document).ready(function () {

        $("#period").dateRangePicker({
            autoClose: false,
        });

        $("#pagesize").change(function(){
            $("#pagesize_form").submit();
        });

        $("#btn-reset").click(function(){
            $("#search_company").val('');
            $("#search_store").val('');
            $("#search_supplier").val('');
            $("#search_reference_no").val('');
            $("#period").val('');
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u417239480/public_html/resources/views/reports/purchases_report.blade.php ENDPATH**/ ?>