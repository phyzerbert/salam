<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('master/lib/vuejs/vue.js')); ?>"></script>
    <script src="<?php echo e(asset('master/lib/vuejs/axios.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel" id="app">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.sales')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.add')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-plus-circle"></i> <?php echo e(__('page.add_sale')); ?></h4>
        </div>

        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <form class="form-layout form-layout-1" action="<?php echo e(route('sale.save')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row mg-b-25">
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.sale_date')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="date" id="sale_date" value="<?php echo e(date('Y-m-d H:i')); ?>" placeholder="<?php echo e(__('page.sale_date')); ?>" autocomplete="off" required>
                                <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.reference_number')); ?>:</label>
                                <input class="form-control" type="text" name="reference_number" value="<?php echo e(old('reference_number')); ?>" placeholder="<?php echo e(__('page.reference_number')); ?>" required>
                                <?php if ($errors->has('reference_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference_number'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.user')); ?>:</label>
                                <select class="form-control select2-show-search" name="user" data-placeholder="<?php echo e(__('page.user')); ?>" required>
                                    <option label="<?php echo e(__('page.user')); ?>"></option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if ($errors->has('user')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mg-b-25">                        
                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.store')); ?>:</label>
                                <select class="form-control select2" name="store" data-placeholder="<?php echo e(__('page.select_store')); ?>" required>
                                    <option label="<?php echo e(__('page.select_store')); ?>"></option>
                                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if ($errors->has('store')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('store'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.customer')); ?>:</label>
                                <select class="form-control select2-show-search" name="customer" data-placeholder="<?php echo e(__('page.select_customer')); ?>" required>
                                    <option label="<?php echo e(__('page.select_customer')); ?>"></option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if ($errors->has('supplier')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('supplier'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.attachment')); ?>:</label>
                                <input type="file" name="attachment" id="file2" class="file-input-styled">
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.status')); ?>:</label>
                                <select class="form-control select2" name="status" data-placeholder="<?php echo e(__('page.status')); ?>">
                                    <option label="<?php echo e(__('page.status')); ?>"></option>
                                    <option value="0"><?php echo e(__('page.pending')); ?></option>
                                    <option value="1"><?php echo e(__('page.received')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row mg-b-25">
                        <div class="col-md-12">
                            <div>
                                <h5 class="mg-t-10" style="float:left"><?php echo e(__('page.order_items')); ?></h5>
                                <a href="#" class="btn btn-primary btn-icon rounded-circle mg-b-10 add-product" style="float:right" @click="add_item()"><div><i class="fa fa-plus"></i></div></a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-colored table-success" id="product_table">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('page.product_name_code')); ?></th>
                                            <th><?php echo e(__('page.product_price')); ?></th>
                                            <th><?php echo e(__('page.quantity')); ?></th>
                                            <th><?php echo e(__('page.product_tax')); ?></th>
                                            <th><?php echo e(__('page.subtotal')); ?></th>
                                            <th style="width:30px"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(item,i) in order_items" :key="i">
                                            <td>
                                                <input type="hidden" name="product_id[]" class="product_id" :value="item.product_id" />
                                                <input type="text" name="product_name[]" class="form-control form-control-sm product" />
                                            </td>
                                            <td><input type="number" class="form-control form-control-sm price" name="price[]" v-model="item.price" placeholder="<?php echo e(__('page.product_price')); ?>" /></td>
                                            <td><input type="number" class="form-control input-sm quantity" name="quantity[]" v-model="item.quantity" placeholder="<?php echo e(__('page.quantity')); ?>" /></td>
                                            <td class="tax">{{item.tax_name}}</td>
                                            <td class="subtotal">
                                                {{item.sub_total}}
                                                <input type="hidden" name="subtotal[]" :value="item.sub_total" />
                                            </td>
                                            <td>
                                                <a href="#" class="btn btn-warning btn-icon rounded-circle mg-t-3 remove-product" @click="remove(i)"><div style="width:25px;height:25px;"><i class="fa fa-times"></i></div></a>
                                            </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="2">Total</td>
                                            <td class="total_quantity">{{total.quantity}}</td>
                                            <td class="total_tax"></td>
                                            <td colspan="2" class="total">{{total.price}}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.note')); ?>:</label>
                                <textarea class="form-control" name="note" rows="5" placeholder="<?php echo e(__('page.note')); ?>"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-layout-footer text-right">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check mg-r-2"></i><?php echo e(__('page.save')); ?></button>
                        <a href="<?php echo e(route('sale.index')); ?>" class="btn btn-warning"><i class="fa fa-times mg-r-2"></i><?php echo e(__('page.cancel')); ?></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/styling/uniform.min.js')); ?>"></script>
<script>
    $(document).ready(function () {

        $("#sale_date").datetimepicker({
            dateFormat: 'yy-mm-dd',
        });
        $(".expire_date").datepicker({
            dateFormat: 'yy-mm-dd',
        });
        
        $('.file-input-styled').uniform({
            fileButtonClass: 'action btn bg-primary tx-white'
        });
        
    });
</script>
<script src="<?php echo e(asset('js/sale_order_items.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\Salam\resources\views/sale/create.blade.php ENDPATH**/ ?>