<?php
    $role = Auth::user()->role->slug;
?>
<form action="" method="POST" class="form-inline top-search-form float-left" id="searchForm">
    <?php echo csrf_field(); ?>
    <?php if($role == 'admin'): ?>    
        <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
            <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </select>
    <?php endif; ?>
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="store_id" id="search_store">
        <option value="" hidden><?php echo e(__('page.select_store')); ?></option>
        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($store_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </select>
    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="reference_no" id="search_reference_no" value="<?php echo e($reference_no); ?>" placeholder="<?php echo e(__('page.reference_no')); ?>">
    <select class="form-control form-control-sm mr-sm-2 mb-2 select2-show-search" name="supplier_id" id="search_supplier" data-placeholder="<?php echo e(__('page.select_supplier')); ?>">
        <option label="<?php echo e(__('page.select_supplier')); ?>"></option>
        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($supplier_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="text" class="form-control form-control-sm mx-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" placeholder="<?php echo e(__('page.purchase_date')); ?>">
    <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
    <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
</form><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/purchase/filter.blade.php ENDPATH**/ ?>