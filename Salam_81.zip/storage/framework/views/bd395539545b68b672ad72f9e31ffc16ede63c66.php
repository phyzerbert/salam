<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.reports')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.income_report')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-credit-card"></i> <?php echo e(__('page.income_report')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="" method="POST" class="form-inline top-search-form float-left" id="searchForm">
                        <?php echo csrf_field(); ?>                        
                        <?php if($role == 'admin'): ?>
                            <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
                                <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                        <select class="form-control form-control-sm mr-sm-2 mb-2 select2-show-search" name="customer_id" id="search_customer" data-placeholder="<?php echo e(__('page.select_customer')); ?>">
                            <option label="<?php echo e(__('page.select_customer')); ?>"></option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($customer_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" class="form-control form-control-sm mx-sm-2 mb-2" name="reference_no" id="search_reference_no" value="<?php echo e($reference_no); ?>" placeholder="<?php echo e(__('page.reference_no')); ?>">
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" placeholder="<?php echo e(__('page.date')); ?>">
                        <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
                        <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th><?php echo e(__('page.date')); ?></th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.sale_reference')); ?></th>
                                <th><?php echo e(__('page.customer')); ?></th>
                                <th><?php echo e(__('page.amount')); ?></th>
                            </tr>
                        </thead>
                        <tbody> 
                            <?php
                                $total_amount = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total_amount += $item->amount;
                                ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="timestamp"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no" ><?php echo e($item->reference_no); ?></td>
                                    
                                    <td class="purchase" data-id="<?php echo e($item->paymentable_id); ?>">
                                        <?php echo e($item->paymentable->reference_no); ?>

                                    </td>
                                    <td class="supplier">
                                        <?php if(isset($item->paymentable->customer->name)): ?><?php echo e($item->paymentable->customer->name); ?><?php endif; ?>
                                    </td>
                                    <td class="amount"> <?php echo e(number_format($item->amount)); ?> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($total_amount)); ?></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $("#payment_form input.date").datetimepicker({
            dateFormat: 'yy-mm-dd',
        });         

        $("#period").dateRangePicker({
            autoClose: false,
        });

        $("#pagesize").change(function(){
            $("#pagesize_form").submit();
        });

        $("#btn-reset").click(function(){
            $("#search_company").val('');
            $("#search_reference_no").val('');
            $("#period").val('');
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/reports/income_report.blade.php ENDPATH**/ ?>