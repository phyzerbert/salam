<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.setting')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.company')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-building"></i> <?php echo e(__('page.company_management')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php if($role == 'admin'): ?>
                        <button type="button" class="btn btn-success btn-sm float-right mg-b-5" id="btn-add"><i class="icon ion-plus mg-r-2"></i> Add New</button>
                    <?php endif; ?>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th class="wd-40">#</th>
                                <th><?php echo e(__('page.name')); ?></th>
                                <th><?php echo e(__('page.stores')); ?></th>
                                <th><?php echo e(__('page.users')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>                                
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="name"><?php echo e($item->name); ?></td>
                                    <td class="stores"><?php echo e($item->stores()->count()); ?></td>
                                    <td class="users"><?php echo e($item->users()->count()); ?></td>
                                    <td class="py-1">
                                        <a href="#" class="btn btn-primary btn-icon rounded-circle mg-r-5 btn-edit" data-id="<?php echo e($item->id); ?>"><div><i class="fa fa-edit"></i></div></a>
                                        <a href="<?php echo e(route('company.delete', $item->id)); ?>" class="btn btn-danger btn-icon rounded-circle mg-r-5" data-id="<?php echo e($item->id); ?>" onclick="return window.confirm('<?php echo e(__('page.are_you_sure')); ?>')"><div><i class="fa fa-trash-o"></i></div></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.add_company')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('company.create')); ?>" id="create_form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.name')); ?></label>
                            <input class="form-control name" type="text" name="name" placeholder="Company Name">
                        </div>
                    </div>    
                    <div class="modal-footer">
                        <button type="submit" id="btn_create" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.edit_company')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('company.edit')); ?>" id="edit_form" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.name')); ?></label>
                            <input class="form-control name" type="text" name="name" placeholder="<?php echo e(__('page.name')); ?>">
                            <span id="edit_name_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>
                    </div>  
                    <div class="modal-footer">
                        <button type="submit" id="btn_update" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        
        $("#btn-add").click(function(){
            $("#create_form input.form-control").val('');
            $("#create_form .invalid-feedback strong").text('');
            $("#addModal").modal();
        });

        $(".btn-edit").click(function(){
            let id = $(this).data("id");
            let name = $(this).parents('tr').find(".name").text().trim();
            $("#edit_form input.form-control").val('');
            $("#editModal .id").val(id);
            $("#editModal .name").val(name);
            $("#editModal").modal();
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/admin/settings/company.blade.php ENDPATH**/ ?>