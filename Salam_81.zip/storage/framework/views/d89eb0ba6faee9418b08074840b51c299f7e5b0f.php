<?php
    $pagesize = session('pagesize');
    if(!$pagesize){$pagesize = 15;}
?>     
<form class="form-inline ml-3 float-left mb-2" action="<?php echo e(route('set_pagesize')); ?>" method="post" id="pagesize_form">
    <?php echo csrf_field(); ?>
    <label for="pagesize" class="control-label"><?php echo e(__('page.show')); ?> :</label>
    <select class="form-control form-control-sm mx-2" name="pagesize" id="pagesize">
        <option value="15" <?php if($pagesize == ''): ?> selected <?php endif; ?>>15</option>
        <option value="25" <?php if($pagesize == '25'): ?> selected <?php endif; ?>>25</option>
        <option value="50" <?php if($pagesize == '50'): ?> selected <?php endif; ?>>50</option>
        <option value="100" <?php if($pagesize == '100'): ?> selected <?php endif; ?>>100</option>
    </select>
</form><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/elements/pagesize.blade.php ENDPATH**/ ?>