<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.profile')); ?></a>
            </nav>
        </div>      
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="container">
                <div class="pd-t-20 pd-sm-t-30">
                    <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-user-circle"></i> <?php echo e(__('page.my_profile')); ?></h4>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card card-body">
                            <div class="text-center profile-image">
                                <img src="<?php if($user->picture): ?><?php echo e(asset($user->picture)); ?><?php else: ?><?php echo e(asset('images/avatar128.png')); ?><?php endif; ?>" width="75%" class="rounded-circle" alt="">
                            </div>
                            <p class="tx-info text-center mt-4"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
                            <p class="tx-primary text-center"><?php echo e($user->role->name); ?></p>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card card-body">                        
                            <form class="form-layout form-layout-1" action="<?php echo e(route('updateuser')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.username')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo e(__('page.username')); ?>" required>
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.first_name')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="first_name" value="<?php echo e($user->first_name); ?>" placeholder="<?php echo e(__('page.first_name')); ?>" required>
                                    <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.last_name')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="last_name" value="<?php echo e($user->last_name); ?>" placeholder="<?php echo e(__('page.last_name')); ?>" required>
                                    <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.phone_number')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="phone_number" value="<?php echo e($user->phone_number); ?>" placeholder="<?php echo e(__('page.phone_number')); ?>" required>
                                    <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.company')); ?>: <span class="tx-danger">*</span></label>
                                    <select class="form-control select2" name="company" class="wd-100" data-placeholder="Select Company">
                                        <option label="<?php echo e(__('page.select_company')); ?>"></option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if($user->company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.picture')); ?>:</label>                                
                                    <label class="custom-file wd-100p">
                                        <input type="file" name="picture" id="file2" class="custom-file-input" accept="image/*">
                                        <span class="custom-file-control custom-file-control-primary"></span>
                                    </label>
                                </div> 
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.password')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="password" name="password" placeholder="Password">
                                </div>
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label"><?php echo e(__('page.confirm_password')); ?>: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="password" name="password_confirmation" placeholder="<?php echo e(__('page.confirm_password')); ?>">
                                </div>
                                <div class="form-layout-footer text-right mt-5">
                                    <button type="submit" class="btn btn-primary tx-20"><i class="fa fa-floppy-o mg-r-2"></i> <?php echo e(__('page.save')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u417239480/public_html/resources/views/profile.blade.php ENDPATH**/ ?>