<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('master/lib/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/sweet-modal/jquery.sweet-modal.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="br-mainpanel" id="app">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.dashboard')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="tx-gray-800 mg-b-5 float-left"><i class="fa fa-dashboard"></i> <?php echo e(__('page.dashboard')); ?></h4>
                    <?php if($role == 'admin'): ?>
                        <?php echo $__env->make('dashboard.top_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>                    
                </div>                
            </div>                      
        </div>
        <div class="br-pagebody">
            <div class="row row-sm">
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-teal rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="ion ion-clock tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.today_purchases')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['today_purchases']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['today_purchases']['count'])); ?> <?php echo e(__('page.purchases')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-sm-t-0">
                    <div class="bg-danger rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="fa fa-truck tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.week_purchases')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['week_purchases']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['week_purchases']['count'])); ?> <?php echo e(__('page.purchases')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-xl-t-0">
                    <div class="bg-primary rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="ion ion-calendar tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.month_purchases')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['month_purchases']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['month_purchases']['count'])); ?> <?php echo e(__('page.purchases')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-xl-t-0">
                    <div class="bg-br-primary rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="ion ion-earth tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.company_balance')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['overall_purchases']['total'] - $return['overall_purchases']['total_paid'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['overall_purchases']['count'])); ?> <?php echo e(__('page.purchases')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
            </div>
            <div class="row row-sm mt-3">
                <div class="col-sm-6 col-xl-3   ">
                    <div class="bg-teal rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="fa fa-sun-o tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.today_sales')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['today_sales']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['today_sales']['count'])); ?> <?php echo e(__('page.sales')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-sm-t-0">
                    <div class="bg-danger rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="ion ion-bag tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.week_sales')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['week_sales']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['week_sales']['count'])); ?> <?php echo e(__('page.sales')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-xl-t-0">
                    <div class="bg-primary rounded overflow-hidden">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="fa fa-calendar tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.month_sales')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['month_sales']['total'])); ?></p>
                                <span class="tx-11 tx-roboto tx-white-6"><?php echo e(number_format($return['month_sales']['count'])); ?> <?php echo e(__('page.sales')); ?></span>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
                
                
                <div class="col-sm-6 col-xl-3 mg-t-20 mg-xl-t-0">
                    <div class="bg-warning rounded overflow-hidden" id="expire_alert">
                        <div class="pd-25 d-flex align-items-center">
                            <i class="fa fa-exclamation-triangle tx-60 lh-0 tx-white op-7"></i>
                            <div class="mg-l-20">
                                <p class="tx-14 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10"><?php echo e(__('page.expired_purchases')); ?></p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e(number_format($return['expired_purchases'])); ?></p>
                                <p class="tx-11 tx-roboto tx-white-6"></p>
                            </div>
                        </div>
                    </div>
                </div><!-- col-3 -->
            </div>
            <div class="br-section-wrapper mt-3">
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <h4 class="tx-primary float-left"><?php echo e(__('page.overview')); ?></h4>
                        <form action="" class="form-inline float-right" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if($role == 'admin'): ?>                                
                                <label for=""><?php echo e(__('page.company')); ?> : </label>                          
                                <select name="chart_company" class="form-control form-control-sm mx-2">
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php if($chart_company == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>
                            <input type="text" class="form-control form-control-sm" name="period" id="period" style="width:250px !important" value="<?php echo e($period); ?>" autocomplete="off" placeholder="<?php echo e(__('page.period')); ?>">
                            <button type="submit" class="btn btn-primary pd-y-7 mg-l-10"> <i class="fa fa-search"></i> <?php echo e(__('page.search')); ?></button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="card card-body">                        
                        <canvas id="line_chart" style="height:400px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/chart.js/Chart.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/sweet-modal/jquery.sweet-modal.min.js')); ?>"></script>
<script>

    var lineData = {
        labels: <?php echo json_encode($key_array); ?>,
        datasets: [
            {
                label: "<?php echo e(__('page.purchase')); ?>",
                backgroundColor: 'rgba(52,152,219, 0.5)',
                borderColor: 'rgba(52,152,219, 1)',
                pointBorderColor: "#fff",
                data: <?php echo json_encode($purchase_array); ?>,
            },{
                label: "<?php echo e(__('page.sale')); ?>",
                backgroundColor: 'rgba(255, 215, 0, 0.5)',
                borderColor: 'rgba(255, 215, 0, 1)',
                pointBorderColor: "#fff",
                data: <?php echo json_encode($sale_array); ?>,
            },{
                label: "<?php echo e(__('page.payment')); ?>",
                backgroundColor: 'rgba(220,53,69, 0.5)',
                borderColor: 'rgba(220,53,69, 1)',
                pointBorderColor: "#fff",
                data: <?php echo json_encode($payment_array); ?>,
            }
        ]
    };
    var lineOptions = {
        responsive: true,
        maintainAspectRatio: false,
        tooltips: {
            callbacks: {
                label: function(tooltipItems, data) {
                    let value = parseInt(data.datasets[tooltipItems.datasetIndex].data[tooltipItems.index]).toLocaleString();
                    return data.datasets[tooltipItems.datasetIndex].label + ": " + value;
                }
            }
        }, 
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: false,
                    callback: function(value, index, values) {
                        return value.toLocaleString();
                    }
                }
            }]
        }
    };
    var ctx = document.getElementById("line_chart").getContext("2d");
    new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});

</script>
<script>
    $(document).ready(function () {
        $("#period").dateRangePicker();
        $("#top_company_filter").change(function(){
            $("#top_filter_form").submit();
        });

        $("#expire_alert").click(function(){
            $.sweetModal({
                content: '<?php echo e($return['expired_purchases']); ?> purchases is expired.',
                icon: $.sweetModal.ICON_WARNING
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u825346279/domains/salampasto.hol.es/public_html/resources/views/dashboard/home.blade.php ENDPATH**/ ?>