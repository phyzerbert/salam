<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.reports')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.product_quantity_alert')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-exclamation-triangle"></i> Product Quantity Alert</h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th class="wd-40">#</th>
                                <th><?php echo e(__('page.image')); ?></th>
                                <th><?php echo e(__('page.product_code')); ?></th>
                                <th><?php echo e(__('page.product_name')); ?></th>
                                <th><?php echo e(__('page.quantity')); ?></th>
                                <th><?php echo e(__('page.alert_quantity')); ?></th>
                            </tr>
                        </thead>
                        <tbody>                                
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $quantity = \App\Models\StoreProduct::where('product_id', $item->id)->sum('quantity');
                                ?>
                                <?php if($item->alert_quantity >= $quantity): ?>                                
                                    <tr>
                                        <td class="wd-40"><?php echo e($loop->index+1); ?></td>
                                        <td class="image py-1 wd-60"><img src="<?php if($item->image): ?><?php echo e(asset($item->image)); ?><?php else: ?><?php echo e(asset('images/no-image.png')); ?><?php endif; ?>" class="wd-40 ht-40 rounded-circle" alt=""></td>
                                        <td><?php echo e($item->code); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($quantity); ?></td>
                                        <td><?php echo e($item->alert_quantity); ?></td>                                        
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>                
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/reports/product_quantity_alert.blade.php ENDPATH**/ ?>