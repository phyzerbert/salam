<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.payment')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.list')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-money"></i> <?php echo e(__('page.payment_management')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th><?php echo e(__('page.date')); ?></th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.amount')); ?></th> 
                                <th><?php echo e(__('page.note')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>                                
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td class="date"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no"><?php echo e($item->reference_no); ?></td>
                                    <td class="amount"><?php echo e($item->amount); ?></td>
                                    <td class="" data-path="<?php echo e($item->attachment); ?>">
                                        <span class="tx-info note"><?php echo e($item->note); ?></span>&nbsp;
                                        <?php if($item->attachment != ""): ?>
                                            <a href="<?php echo e(asset($item->attachment)); ?>" download><i class="fa fa-paperclip"></i></a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-1">
                                        <a href="#" class="btn btn-primary btn-icon rounded-circle mg-r-5 btn-edit" data-id="<?php echo e($item->id); ?>"><div><i class="fa fa-edit"></i></div></a>
                                        <a href="<?php echo e(route('payment.delete', $item->id)); ?>" class="btn btn-danger btn-icon rounded-circle mg-r-5" data-id="<?php echo e($item->id); ?>" onclick="return window.confirm('<?php echo e(__('page.are_you_sure')); ?>')"><div><i class="fa fa-trash-o"></i></div></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table> 
                </div>
            </div>
        </div>                
    </div>

    <!-- The Modal -->
    
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.edit_payment')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('payment.edit')); ?>" id="edit_form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="id">
                    <div class="modal-body">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.date')); ?></label>
                                <input class="form-control date" type="text" name="date" autocomplete="off" value="<?php echo e(date('Y-m-d H:i')); ?>" placeholder="<?php echo e(__('page.date')); ?>">
                            </div>                        
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.reference_no')); ?></label>
                                <input class="form-control reference_no" type="text" name="reference_no" placeholder="<?php echo e(__('page.reference_number')); ?>">
                            </div>                                                
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.amount')); ?></label>
                                <input class="form-control amount" type="text" name="amount" placeholder="<?php echo e(__('page.amount')); ?>">
                            </div>                                               
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.attachment')); ?></label>
                                <label class="custom-file wd-100p">
                                    <input type="file" name="attachment" id="file2" class="custom-file-input">
                                    <span class="custom-file-control custom-file-control-primary"></span>
                                </label>
                            </div>
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.note')); ?></label>
                                <textarea class="form-control note" type="text" name="note" placeholder="<?php echo e(__('page.note')); ?>"></textarea>
                            </div>
                    </div>  
                    <div class="modal-footer">
                        <button type="submit" id="btn_update" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        
        // $("#btn-add").click(function(){
        //     $("#create_form input.form-control").val('');
        //     $("#create_form .invalid-feedback strong").text('');
        //     $("#addModal").modal();
        // });

        $("#edit_form input.date").datetimepicker({
            dateFormat: 'yy-mm-dd',
        });

        $(".btn-edit").click(function(){
            let id = $(this).data("id");
            let date = $(this).parents('tr').find(".date").text().trim();
            let reference_no = $(this).parents('tr').find(".reference_no").text().trim();
            let amount = $(this).parents('tr').find(".amount").text().trim();
            let note = $(this).parents('tr').find(".note").text().trim();
            $("#editModal input.form-control").val('');
            $("#editModal .id").val(id);
            $("#editModal .date").val(date);
            $("#editModal .reference_no").val(reference_no);
            $("#editModal .amount").val(amount);
            $("#editModal .note").val(note);
            $("#editModal").modal();
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u888404772/public_html/resources/views/payment/index.blade.php ENDPATH**/ ?>