<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.product')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.list')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-cubes"></i> <?php echo e(__('page.product_management')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('product.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-success btn-sm float-right tx-white mg-b-5" id="btn-add"><i class="fa fa-plus mg-r-2"></i> Add New</a>                    
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:30px;">#</th>
                                <th><?php echo e(__('page.product_code')); ?></th>
                                <th><?php echo e(__('page.product_name')); ?></th>
                                <th><?php echo e(__('page.category')); ?></th>
                                <th><?php echo e(__('page.product_cost')); ?></th>
                                <th><?php echo e(__('page.product_price')); ?></th>
                                <th><?php echo e(__('page.quantity')); ?></th>
                                <th><?php echo e(__('page.product_unit')); ?></th>
                                <th><?php echo e(__('page.alert_quantity')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>                                
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $quantity = $item->store_products()->sum('quantity');
                            ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="code"><?php echo e($item->code); ?></td>
                                    <td class="name"><?php echo e($item->name); ?></td>
                                    <td class="category"><?php echo e($item->category->name); ?></td>
                                    <td class="cost"><?php echo e(number_format($item->cost)); ?></td>
                                    <td class="price"><?php echo e(number_format($item->price)); ?></td>
                                    <td class="quantity"><?php echo e($quantity); ?></td>
                                    <td class="unit"><?php echo e($item->unit); ?></td>
                                    <td class="alert_quantity"><?php echo e($item->alert_quantity); ?></td>
                                    <td class="py-2 dropdown" align="center">
                                        <a href="#" class="btn btn-info btn-with-icon nav-link" data-toggle="dropdown">
                                            <div class="ht-30">
                                                <span class="icon wd-30"><i class="fa fa-send"></i></span>
                                                <span class="pd-x-15">Action</span>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-header action-dropdown pd-l-5 pd-r-5 bd-t-1" style="min-width:9rem">
                                            <ul class="list-unstyled user-profile-nav">
                                                <li><a href="<?php echo e(route('product.detail', $item->id)); ?>"><i class="icon ion-eye  "></i> <?php echo e(__('page.details')); ?></a></li>
                                                                                                
                                                <li><a href="<?php echo e(route('product.edit', $item->id)); ?>"><i class="icon ion-compose"></i> <?php echo e(__('page.edit')); ?></a></li>
                                                <li><a href="<?php echo e(route('product.delete', $item->id)); ?>" onclick="return window.confirm('Are you sure?')"><i class="icon ion-trash-a"></i> <?php echo e(__('page.delete')); ?></a></li>                                                
                                            </ul>
                                        </div>                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $("#btn-reset").click(function(){
            $("#search_code").val('');
            $("#search_name").val('');
            $("#search_category").val('');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u417239480/public_html/resources/views/product/index.blade.php ENDPATH**/ ?>