<?php $__env->startSection('content'); ?>
    <?php
        $verify_messages = [
            '10' => __('page.concurrent_verifications_to_the_same_number_are_not_allowed'),
            '4' => __('page.invalid_credentials_were_provided'),
            '5' => __('page.internal_error'),
        ];
    ?>
    <div class="d-flex align-items-center justify-content-center bg-br-primary ht-100v">

        <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse"><span class="tx-normal"><?php echo e(config("app.name")); ?></span></div>
            <div class="tx-center my-4"><?php echo e(__('page.enter_your_credentials_below')); ?></div>
            
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                <span class="text-danger mt-2" role="alert">
                    <strong>
                        <?php if(isset($verify_messages[$message])): ?>
                            <?php echo e($verify_messages[$message]); ?>

                        <?php else: ?>
                            <?php echo e(__('page.invalid_verification_request')); ?>

                        <?php endif; ?>
                    </strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="<?php echo e(__('page.username')); ?>">
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <input id="password" type="password" class="form-control" name="password" required autocomplete="current-password" placeholder="<?php echo e(__('page.password')); ?>">

                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label class="ckbox">
                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <span><?php echo e(__('page.remember_me')); ?></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-info btn-block"><?php echo e(__('page.sign_in')); ?></button>

                <div class="form-group text-center mt-3">
                    <a href="<?php echo e(route('lang', 'en')); ?>" class="btn btn-outline p-0 <?php if(config('app.locale') == 'en'): ?> border-primary border-2 <?php endif; ?>" title="English"><img src="<?php echo e(asset('images/lang/en.png')); ?>" width="45px"></a>
                    <a href="<?php echo e(route('lang', 'es')); ?>" class="btn btn-outline ml-2 p-0 <?php if(config('app.locale') == 'es'): ?> border-primary border-2 <?php endif; ?>" title="Spanish"><img src="<?php echo e(asset('images/lang/es.png')); ?>" width="45px"></a>
                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\Salam\resources\views/auth/login.blade.php ENDPATH**/ ?>