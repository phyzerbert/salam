<form action="" class="form-inline float-right" method="post" id="company_filter_form">
    <?php echo csrf_field(); ?>
    <label for="company_filter"><?php echo e(__('page.company')); ?> : </label>
    <select name="company_id" id="company_filter" class="form-control form-control-sm ml-2">
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/elements/company_filter.blade.php ENDPATH**/ ?>