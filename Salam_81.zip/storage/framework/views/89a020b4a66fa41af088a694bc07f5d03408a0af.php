<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/lib/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.reports')); ?></a>
                <a class="breadcrumb-item" href="<?php echo e(route('report.users_report')); ?>"><?php echo e(__('page.users_report')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.sales')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-credit-card-alt"></i>  <?php echo e(__('page.user_sales')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">                                
                <div class="ht-md-40 pd-x-20 bg-gray-200 rounded d-flex align-items-center">
                    <ul class="nav nav-outline align-items-center flex-column flex-md-row" role="tablist">
                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="<?php echo e(route('report.users_report.purchases', $user->id)); ?>" role="tab"><?php echo e(__('page.purchases')); ?></a></li>
                        <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="<?php echo e(route('report.users_report.sales', $user->id)); ?>" role="tab"><?php echo e(__('page.sales')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="<?php echo e(route('report.users_report.payments', $user->id)); ?>" role="tab"><?php echo e(__('page.payments')); ?></a></li>
                    </ul>
                </div>
                <div class="mt-2">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="" method="POST" class="form-inline float-left" id="searchForm">
                        <?php echo csrf_field(); ?>
                        <?php if($role == 'admin'): ?>    
                            <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
                                <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                            </select>
                        <?php endif; ?>
                        <select class="form-control form-control-sm mr-sm-2 mb-2" name="store_id" id="search_store">
                            <option value="" hidden><?php echo e(__('page.select_store')); ?></option>
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($store_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                        </select>
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="reference_no" id="search_reference_no" value="<?php echo e($reference_no); ?>" placeholder="<?php echo e(__('page.reference_no')); ?>">
                        <select class="form-control form-control-sm mr-sm-2 mb-2" name="supplier_id" id="search_supplier">
                            <option value="" hidden><?php echo e(__('page.select_customer')); ?></option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($customer_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" placeholder="<?php echo e(__('page.sale_date')); ?>">
                        <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
                        <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th><?php echo e(__('page.date')); ?></th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.company')); ?></th>
                                <th><?php echo e(__('page.store')); ?></th>
                                <th><?php echo e(__('page.user')); ?></th>
                                <th><?php echo e(__('page.customer')); ?></th>
                                <th><?php echo e(__('page.grand_total')); ?></th>
                                <th><?php echo e(__('page.paid')); ?></th>
                                <th><?php echo e(__('page.balance')); ?></th>
                                <th><?php echo e(__('page.sale_status')); ?></th>
                                
                            </tr>
                        </thead>
                        <tbody> 
                            <?php
                                $total_grand = $total_paid = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $grand_total = $item->orders()->sum('subtotal');
                                    $paid = $item->payments()->sum('amount');
                                    $total_grand += $grand_total;
                                    $total_paid += $paid;
                                ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td class="timestamp"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no"><?php echo e($item->reference_no); ?></td>
                                    <td class="company"><?php echo e($item->company->name); ?></td>
                                    <td class="store"><?php echo e($item->store->name); ?></td>
                                    <td class="user"><?php echo e($item->biller->name); ?></td>
                                    <td class="customer" data-id="<?php echo e($item->customer_id); ?>"><?php echo e($item->customer->name); ?></td>
                                    <td class="grand_total"> <?php echo e(number_format($grand_total)); ?> </td>
                                    <td class="paid"> <?php echo e(number_format($paid)); ?> </td>
                                    <td> <?php echo e(number_format($grand_total - $paid)); ?> </td>
                                    <td class="status">
                                        <?php if($item->status == 1): ?>
                                            <span class="badge badge-success"><i class="fa fa-check"></i> <?php echo e(__('page.received')); ?></span>
                                        <?php elseif($item->status == 0): ?>
                                            <span class="badge badge-danger"><i class="fa fa- exclamation-triangle"></i><?php echo e(__('page.pending')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="7"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($total_grand)); ?></td>
                                <td><?php echo e(number_format($total_paid)); ?></td>
                                <td><?php echo e(number_format($total_grand - $total_paid)); ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $("#payment_form input.date").datetimepicker({
            dateFormat: 'yy-mm-dd',
        });

        $("#period").dateRangePicker({
            autoClose: false,
        });

        $("#pagesize").change(function(){
            $("#pagesize_form").submit();
        });

        $("#btn-reset").click(function(){
            $("#search_company").val('');
            $("#search_store").val('');
            $("#search_supplier").val('');
            $("#search_reference_no").val('');
            $("#period").val('');
        });

        $("ul.nav a.nav-link").click(function(){
            location.href = $(this).attr('href');
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/reports/users_report/sales.blade.php ENDPATH**/ ?>