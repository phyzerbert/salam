<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.home')); ?></a>
                <a class="breadcrumb-item" href="#"><?php echo e(__('page.product')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.add')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-plus-circle"></i> <?php echo e(__('page.add_new_product')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <form class="form-layout form-layout-1" action="<?php echo e(route('product.save')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row mg-b-25">
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_name')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="name" placeholder="<?php echo e(__('page.product_name')); ?>" required>
                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_code')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="code" placeholder="<?php echo e(__('page.product_code')); ?>" required>
                                <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.barcode_symbology')); ?>: <span class="tx-danger">*</span></label>
                                <select class="form-control select2" name="barcode_symbology_id" data-placeholder="<?php echo e(__('page.barcode_symbology')); ?>" required>
                                    <option label="<?php echo e(__('page.barcode_symbology')); ?>"></option>
                                    <?php $__currentLoopData = $barcode_symbologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if ($errors->has('barcode_symbology_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('barcode_symbology_id'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mg-b-25">
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.select_category')); ?>: <span class="tx-danger">*</span></label>
                                <select class="form-control select2" name="category_id" data-placeholder="<?php echo e(__('page.select_category')); ?>" required>
                                    <option label="<?php echo e(__('page.select_category')); ?>"></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if ($errors->has('category_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_id'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_unit')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="unit" placeholder="<?php echo e(__('page.product_unit')); ?>" required>
                                <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_cost')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="cost" placeholder="<?php echo e(__('page.product_cost')); ?>" required>
                                <?php if ($errors->has('cost')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cost'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mg-b-25">
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_price')); ?>: <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" name="price" placeholder="<?php echo e(__('page.product_price')); ?>" required>
                                <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_tax')); ?>:</label>
                                <select class="form-control select2" name="tax_id" data-placeholder="<?php echo e(__('page.select_tax')); ?>">
                                    <option label="<?php echo e(__('page.select_tax')); ?>"></option>
                                    <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>                        
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.tax_method')); ?>:</label>
                                <select class="form-control select2" name="tax_method" data-placeholder="<?php echo e(__('page.select_tax_method')); ?>">
                                    <option label="<?php echo e(__('page.select_tax_method')); ?>"></option>
                                    <option value="0">Inclusive</option>
                                    <option value="1">Exclusive</option>
                                </select>
                            </div>
                        </div>
                    </div>                    
                    <div class="row mg-b-25">
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.alert_quantity')); ?>:</label>
                                <input class="form-control" type="number" name="alert_quantity" placeholder="<?php echo e(__('page.alert_quantity')); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.supplier')); ?>:</label>
                                <select class="form-control select2-show-search" name="supplier_id" data-placeholder="<?php echo e(__('page.product_supplier')); ?>">
                                    <option label="<?php echo e(__('page.product_supplier')); ?>"></option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </select>
                            </div>
                        </div>                        
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_image')); ?>:</label>                                
                                <label class="custom-file wd-100p">
                                    <input type="file" name="image" id="file2" class="file-input-styled" accept="image/*">
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"><?php echo e(__('page.product_detail')); ?>:</label>
                                <textarea class="form-control" name="detail" rows="5" placeholder="<?php echo e(__('page.product_detail')); ?>"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-layout-footer text-right">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check mg-r-2"></i><?php echo e(__('page.save')); ?></button>
                        <a href="<?php echo e(route('product.index')); ?>" class="btn btn-warning"><i class="fa fa-times mg-r-2"></i><?php echo e(__('page.cancel')); ?></a>
                    </div>
                </form>
            </div>
        </div>                
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/lib/styling/uniform.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        
        $('.file-input-styled').uniform({
            fileButtonClass: 'action btn bg-primary tx-white'
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u825346279/domains/salampasto.hol.es/public_html/resources/views/product/create.blade.php ENDPATH**/ ?>