<?php
    $user = Auth::user();
    $role = $user->role->slug;
?>
<div class="br-header">
    <div class="br-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href="<?php echo e(route('home')); ?>"><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href="<?php echo e(route('home')); ?>"><i class="icon ion-navicon-round"></i></a></div>        
    </div>
    <div class="br-header-right">
        <nav class="nav">
            <div class="user-company mx-5 tx-25">
                <?php if(Auth::user()->hasRole('user')): ?>
                    <?php echo e(Auth::user()->company->name); ?>

                <?php endif; ?>
            </div>
            <div class="dropdown dropdown-lang">
                <?php $locale = session()->get('locale'); ?>
                <a href="#" class="navbar-nav-link d-flex align-items-center dropdown-toggle mg-t-15" data-toggle="dropdown">                    
                    <?php switch($locale):
                        case ('en'): ?>
                            <img src="<?php echo e(asset('images/lang/en.png')); ?>" width="30px">&nbsp;&nbsp;English
                            <?php break; ?>
                        <?php case ('es'): ?>
                            <img src="<?php echo e(asset('images/lang/es.png')); ?>" width="30px">&nbsp;&nbsp;Spanish
                            <?php break; ?>
                        <?php default: ?>
                            <img src="<?php echo e(asset('images/lang/es.png')); ?>" width="30px">&nbsp;&nbsp;Spanish
                    <?php endswitch; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="<?php echo e(route('lang', 'en')); ?>"><img src="<?php echo e(asset('images/lang/en.png')); ?>" class="rounded-circle wd-30 ht-30"> English</a>
                    <a class="dropdown-item" href="<?php echo e(route('lang', 'es')); ?>"><img src="<?php echo e(asset('images/lang/es.png')); ?>" class="rounded-circle wd-30 ht-30"> Spanish</a>
                </div>
            </div>
            <div class="dropdown">
                <a href="<?php echo e(route('home')); ?>" class="nav-link nav-link-profile" data-toggle="dropdown">
                    <span class="logged-name hidden-md-down"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></span>
                    <img src="<?php if(Auth::user()->picture != ''): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" class="wd-32 rounded-circle" alt="">
                    <span class="square-10 bg-success"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-header wd-200">
                    <ul class="list-unstyled user-profile-nav">
                        <li><a href="<?php echo e(route('profile')); ?>"><i class="icon ion-ios-person"></i> <?php echo e(__('page.my_profile')); ?></a></li>
                        
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();" 
                            ><i class="icon ion-power"></i> <?php echo e(__('page.sign_out')); ?></a>
                        </li>
                    </ul>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </nav>
        
    </div>
</div><?php /**PATH E:\2019-Jun\Store\Source\Salam\resources\views/layouts/header.blade.php ENDPATH**/ ?>