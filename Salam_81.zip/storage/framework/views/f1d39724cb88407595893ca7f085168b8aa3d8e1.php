<?php
    $page = config('site.page');
    $role = Auth::user()->role->slug;
?>
<div class="br-logo"><a href="<?php echo e(route('home')); ?>" class="mx-auto"><span><?php echo e(config('app.name')); ?></span></a></div>
<div class="br-sideleft overflow-y-auto">
    <label class="sidebar-label pd-x-15 mg-t-20">Navigation</label>
    <div class="br-sideleft-menu">
        <a href="<?php echo e(route('home')); ?>" class="br-menu-link <?php if($page == 'home'): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
                <span class="menu-item-label"><?php echo e(__('page.dashboard')); ?></span>
            </div>
        </a>

        
        <?php
            $purchase_items = ['purchase', 'purchase_list', 'purchase_create'];
        ?>

        <a href="#" class="br-menu-link <?php if($page == in_array($page, $purchase_items)): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-log-in tx-24"></i>
                <span class="menu-item-label"><?php echo e(__('page.purchases')); ?></span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div>
        </a>
        <ul class="br-menu-sub nav flex-column">
            <li class="nav-item"><a href="<?php echo e(route('purchase.index')); ?>" class="nav-link <?php if($page == 'purchase_list'): ?> active <?php endif; ?>"><?php echo e(__('page.purchases_list')); ?></a></li>
            <?php if($role == 'user'): ?>
                <li class="nav-item"><a href="<?php echo e(route('purchase.create')); ?>" class="nav-link <?php if($page == 'purchase_create'): ?> active <?php endif; ?>"><?php echo e(__('page.add_purchase')); ?></a></li>
            <?php endif; ?>
        </ul>

        
        <?php
            $sale_items = ['sale', 'sale_list', 'sale_create'];
        ?>

        <a href="#" class="br-menu-link <?php if($page == in_array($page, $sale_items)): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-log-out tx-24"></i>
                <span class="menu-item-label"><?php echo e(__('page.sales')); ?></span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div>
        </a>
        <ul class="br-menu-sub nav flex-column">
            <li class="nav-item"><a href="<?php echo e(route('sale.index')); ?>" class="nav-link <?php if($page == 'sale_list'): ?> active <?php endif; ?>"><?php echo e(__('page.sales_list')); ?></a></li>
            <?php if($role == 'user'): ?>
                <li class="nav-item"><a href="<?php echo e(route('sale.create')); ?>" class="nav-link <?php if($page == 'sale_create'): ?> active <?php endif; ?>"><?php echo e(__('page.add_sale')); ?></a></li>
            <?php endif; ?>
        </ul>
        
        <a href="<?php echo e(route('product.index')); ?>" class="br-menu-link <?php if($page == 'product'): ?> active <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon fa fa-cube tx-22"></i>
                <span class="menu-item-label"><?php echo e(__('page.product')); ?></span>
            </div>
        </a>

        <?php
            $report_items = [
                'overview_chart', 
                'company_chart', 
                'store_chart', 
                'product_quantity_alert', 
                'product_expiry_alert', 
                'products_report', 
                'categories_report', 
                'sales_report', 
                'purchases_report', 
                'daily_sales', 
                'monthly_sales', 
                'payments_report', 
                'customers_report', 
                'suppliers_report', 
                'users_report',
            ];
        ?>

        <a href="#" class="br-menu-link <?php if($page == in_array($page, $report_items)): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon fa fa-file-text-o tx-24"></i>
                <span class="menu-item-label"><?php echo e(__('page.reports')); ?></span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div>
        </a>
        <ul class="br-menu-sub nav flex-column">
            <li class="nav-item"><a href="<?php echo e(route('report.overview_chart')); ?>" class="nav-link <?php if($page == 'overview_chart'): ?> active <?php endif; ?>"><?php echo e(__('page.overview_chart')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.company_chart')); ?>" class="nav-link <?php if($page == 'company_chart'): ?> active <?php endif; ?>"><?php echo e(__('page.company_chart')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.store_chart')); ?>" class="nav-link <?php if($page == 'store_chart'): ?> active <?php endif; ?>"><?php echo e(__('page.store_chart')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.product_quantity_alert')); ?>" class="nav-link <?php if($page == 'product_quantity_alert'): ?> active <?php endif; ?>"><?php echo e(__('page.product_quantity_alert')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.product_expiry_alert')); ?>" class="nav-link <?php if($page == 'product_expiry_alert'): ?> active <?php endif; ?>"><?php echo e(__('page.product_expiry_alert')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.expired_purchases_report')); ?>" class="nav-link <?php if($page == 'expired_purchases_report'): ?> active <?php endif; ?>"><?php echo e(__('page.expired_purchases_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.products_report')); ?>" class="nav-link <?php if($page == 'products_report'): ?> active <?php endif; ?>"><?php echo e(__('page.product_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.categories_report')); ?>" class="nav-link <?php if($page == 'categories_report'): ?> active <?php endif; ?>"><?php echo e(__('page.category_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.sales_report')); ?>" class="nav-link <?php if($page == 'sales_report'): ?> active <?php endif; ?>"><?php echo e(__('page.sales_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.purchases_report')); ?>" class="nav-link <?php if($page == 'purchases_report'): ?> active <?php endif; ?>"><?php echo e(__('page.purchases_report')); ?></a></li>
            
            <li class="nav-item"><a href="<?php echo e(route('report.payments_report')); ?>" class="nav-link <?php if($page == 'payments_report'): ?> active <?php endif; ?>"><?php echo e(__('page.payments_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.income_report')); ?>" class="nav-link <?php if($page == 'income_report'): ?> active <?php endif; ?>"><?php echo e(__('page.income_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.customers_report')); ?>" class="nav-link <?php if($page == 'customers_report'): ?> active <?php endif; ?>"><?php echo e(__('page.customers_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.suppliers_report')); ?>" class="nav-link <?php if($page == 'suppliers_report'): ?> active <?php endif; ?>"><?php echo e(__('page.suppliers_report')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('report.users_report')); ?>" class="nav-link <?php if($page == 'users_report'): ?> active <?php endif; ?>"><?php echo e(__('page.users_report')); ?></a></li>
        </ul>

        <?php
            $people_items = ['user', 'customer', 'supplier'];
        ?>
        <a href="#" class="br-menu-link <?php if($page == in_array($page, $people_items)): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-person-stalker tx-24"></i>
                <span class="menu-item-label"><?php echo e(__('page.people')); ?></span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div>
        </a>
        <ul class="br-menu-sub nav flex-column">
            <?php if($role == 'admin'): ?>
                <li class="nav-item"><a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php if($page == 'user'): ?> active <?php endif; ?>"><?php echo e(__('page.user')); ?></a></li>
            <?php endif; ?>
            <li class="nav-item"><a href="<?php echo e(route('customer.index')); ?>" class="nav-link <?php if($page == 'customer'): ?> active <?php endif; ?>"><?php echo e(__('page.customer')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('supplier.index')); ?>" class="nav-link <?php if($page == 'supplier'): ?> active <?php endif; ?>"><?php echo e(__('page.supplier')); ?></a></li>
        </ul>
        <?php if($role == 'admin'): ?>
        
        <?php
            $setting_items = ['category', 'store', 'company', 'tax_rate'];
        ?>
        <a href="#" class="br-menu-link <?php if($page == in_array($page, $setting_items)): ?> active show-sub <?php endif; ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-gear-outline tx-24"></i>
                <span class="menu-item-label"><?php echo e(__('page.setting')); ?></span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div>
        </a>
        <ul class="br-menu-sub nav flex-column">
            <li class="nav-item"><a href="<?php echo e(route('category.index')); ?>" class="nav-link <?php if($page == 'category'): ?> active <?php endif; ?>"><?php echo e(__('page.category')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('company.index')); ?>" class="nav-link <?php if($page == 'company'): ?> active <?php endif; ?>"><?php echo e(__('page.company')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('store.index')); ?>" class="nav-link <?php if($page == 'store'): ?> active <?php endif; ?>"><?php echo e(__('page.store')); ?></a></li>
            <li class="nav-item"><a href="<?php echo e(route('tax_rate.index')); ?>" class="nav-link <?php if($page == 'tax_rate'): ?> active <?php endif; ?>"><?php echo e(__('page.tax_rate')); ?></a></li>
        </ul>
        <?php endif; ?>
    </div>

    <br>
</div><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/layouts/aside.blade.php ENDPATH**/ ?>