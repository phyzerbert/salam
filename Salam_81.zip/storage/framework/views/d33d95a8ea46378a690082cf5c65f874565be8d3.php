<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.report')); ?></a>
                <a class="breadcrumb-item active" href="#"><?php echo e(__('page.suppliers_report')); ?></a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-user-circle"></i> <?php echo e(__('page.suppliers_report')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="">
                    <?php echo $__env->make('elements.pagesize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="" method="POST" class="form-inline float-left" id="searchForm">
                        <?php echo csrf_field(); ?>
                        <?php if($role == 'admin'): ?>
                            <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
                                <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="name" id="search_name" value="<?php echo e($name); ?>" placeholder="<?php echo e(__('page.name')); ?>">
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="supplier_company" id="search_supplier_company" value="<?php echo e($supplier_company); ?>" placeholder="<?php echo e(__('page.supplier_company')); ?>">
                        <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="phone_number" id="search_phone" value="<?php echo e($phone_number); ?>" placeholder="<?php echo e(__('page.phone_number')); ?>">
                        
                        <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
                        <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th class="wd-40">#</th>
                                <th><?php echo e(__('page.company')); ?></th>
                                <th><?php echo e(__('page.name')); ?></th>
                                <th><?php echo e(__('page.phone')); ?></th>
                                <th><?php echo e(__('page.email_address')); ?></th>
                                <th><?php echo e(__('page.total_purchases')); ?></th>
                                <th><?php echo e(__('page.total_amount')); ?></th>
                                <th><?php echo e(__('page.paid')); ?></th>
                                <th><?php echo e(__('page.balance')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody> 
                            <?php
                                $footer_total_purchases = $footer_total_amount = $footer_paid = 0;
                            ?>                               
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $purchases_array = $item->purchases()->pluck('id');
                                    $total_purchases = $item->purchases()->count();
                                    $mod_total_amount = \App\Models\Order::whereIn('orderable_id', $purchases_array)->where('orderable_type', "App\Models\Purchase");
                                    $mod_paid = \App\Models\Payment::whereIn('paymentable_id', $purchases_array)->where('paymentable_type', "App\Models\Purchase");

                                    if($company_id != ''){
                                        $company = \App\Models\Company::find($company_id);
                                        $company_purchases = $company->purchases()->pluck('id');

                                        $mod_total_amount = $mod_total_amount->whereIn('orderable_id', $company_purchases);
                                        $mod_paid = $mod_paid->whereIn('paymentable_id', $company_purchases);
                                    }

                                    $total_amount = $mod_total_amount->sum('subtotal');
                                    $paid = $mod_paid->sum('amount');  

                                    $footer_total_purchases += $total_purchases;
                                    $footer_total_amount += $total_amount;
                                    $footer_paid += $paid;
                                ?>                              
                                <tr>
                                    <td class="wd-40"><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td><?php echo e($item->company); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->phone_number); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e(number_format($total_purchases)); ?></td>
                                    <td><?php echo e(number_format($total_amount)); ?></td>                                        
                                    <td><?php echo e(number_format($paid)); ?></td>
                                    <td><?php echo e(number_format($total_amount - $paid)); ?></td>                                      
                                    <td>
                                        <a href="<?php echo e(route('report.suppliers_report.purchases', $item->id)); ?>" class="badge badge-primary"><?php echo e(__('page.view_reports')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($footer_total_purchases)); ?></td>
                                <td><?php echo e(number_format($footer_total_amount)); ?></td>
                                <td><?php echo e(number_format($footer_paid)); ?></td>
                                <td><?php echo e(number_format($footer_total_amount - $footer_paid)); ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $("#btn-reset").click(function(){
            $("#search_name").val('');
            $("#search_company").val('');
            $("#search_supplier_company").val('');
            $("#search_phone").val('');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u417239480/public_html/resources/views/reports/suppliers_report/index.blade.php ENDPATH**/ ?>