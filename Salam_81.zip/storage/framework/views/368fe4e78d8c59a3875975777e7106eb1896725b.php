<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('page.reports')); ?></a>
                <a class="breadcrumb-item active" href="#">Categories Report</a>
            </nav>
        </div>
        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"><i class="fa fa-code-fork"></i> <?php echo e(__('page.category_report')); ?></h4>
        </div>
        
        <?php
            $role = Auth::user()->role->slug;
        ?>
        <div class="br-pagebody">
            <div class="br-section-wrapper">                    
                <form action="" method="POST" class="form-inline float-left" id="searchForm">
                    <?php echo csrf_field(); ?>
                    <?php if($role == 'admin'): ?>
                        <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
                            <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>
                    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="name" id="search_name" value="<?php echo e($name); ?>" placeholder="<?php echo e(__('page.category_name')); ?>">

                    <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
                    <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
                </form>
                <div class="table-responsive mg-t-2">
                    <table class="table table-bordered table-colored table-primary table-hover">
                        <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th class="wd-40">#</th>
                                <th><?php echo e(__('page.category_name')); ?></th>
                                <th><?php echo e(__('page.purchased')); ?></th>
                                <th><?php echo e(__('page.sold')); ?></th>
                                <th><?php echo e(__('page.purchased_amount')); ?></th>
                                <th><?php echo e(__('page.sold_amount')); ?></th>
                                <th><?php echo e(__('page.profit_loss')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total_purchased_quantity = $total_sold_quantity = $total_purchased_amount = $total_sold_amount = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $product_array = $item->products()->pluck('id');

                                    $mod_purchased_quantity = \App\Models\Order::whereIn('product_id', $product_array)->where('orderable_type', "App\Models\Purchase");
                                    $mod_sold_quantity = \App\Models\Order::whereIn('product_id', $product_array)->where('orderable_type', "App\Models\Sale");                                    
                                    $mod_purchased_amount = \App\Models\Order::whereIn('product_id', $product_array)->where('orderable_type', "App\Models\Purchase");
                                    $mod_sold_amount = \App\Models\Order::whereIn('product_id', $product_array)->where('orderable_type', "App\Models\Sale");

                                    if($company_id != ''){
                                        $company = \App\Models\Company::find($company_id);
                                        $company_purchases = $company->purchases()->pluck('id');
                                        $company_sales = $company->sales()->pluck('id');

                                        $purchased_quantity = $mod_purchased_quantity->whereIn('orderable_id', $company_purchases);
                                        $sold_quantity = $mod_sold_quantity->whereIn('orderable_id', $company_sales);                                    
                                        $purchased_amount = $mod_purchased_amount->whereIn('orderable_id', $company_purchases);
                                        $sold_amount = $mod_sold_amount->whereIn('orderable_id', $company_sales);
                                    }

                                    $purchased_quantity = $mod_purchased_quantity->sum('quantity');
                                    $sold_quantity = $mod_sold_quantity->sum('quantity');                                    
                                    $purchased_amount = $mod_purchased_amount->sum('subtotal');
                                    $sold_amount = $mod_sold_amount->sum('subtotal');

                                    $total_purchased_quantity += $purchased_quantity;
                                    $total_sold_quantity += $sold_quantity;
                                    $total_purchased_amount += $purchased_amount;
                                    $total_sold_amount += $sold_amount;

                                ?>                              
                                <tr>
                                    <td class="wd-40"><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e(number_format($purchased_quantity)); ?></td>
                                    <td><?php echo e(number_format($sold_quantity)); ?></td>                                        
                                    <td><?php echo e(number_format($purchased_amount)); ?></td>
                                    <td><?php echo e(number_format($sold_amount)); ?></td>                                      
                                    <td><?php echo e(number_format($sold_amount - $purchased_amount)); ?></td>                                      
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>                        
                        <tfoot>
                            <tr>
                                <td colspan="2"><?php echo e(__('page.total')); ?></td>
                                <td><?php echo e(number_format($total_purchased_quantity)); ?></td>
                                <td><?php echo e(number_format($total_sold_quantity)); ?></td>
                                <td><?php echo e(number_format($total_purchased_amount)); ?></td>
                                <td><?php echo e(number_format($total_sold_amount)); ?></td>
                                <td><?php echo e(number_format($total_sold_amount - $total_purchased_amount)); ?></td>
                            </tr>
                        </tfoot>
                    </table>                
                    <div class="clearfix mt-2">
                        <div class="float-left" style="margin: 0;">
                            <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Items</p>
                        </div>
                        <div class="float-right" style="margin: 0;">
                            <?php echo $data->appends([])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $("#pagesize").change(function(){
            $("#pagesize_form").submit();
        });
        $("#btn-reset").click(function(){
            $("#search_name").val('');
            $("#search_company").val('');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Store\Source\bilal\resources\views/reports/categories_report.blade.php ENDPATH**/ ?>